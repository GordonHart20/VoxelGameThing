package com.voxelite.lighting;

import org.joml.Matrix4f;

import com.voxelite.engine.Camera;
import com.voxelite.toolbox.Maths;

public class StaticShader extends ShaderProcessor {
	
	private static final String VERTEX_FILE = "src/com/voxelite/lighting/vertex.glsl";
	private static final String FRAG_FILE = "src/com/voxelite/lighting/frag.glsl";
	
	private int location_transMatrix;
	private int location_projectionMatrix;
	private int location_viewMatrix;
	
	public StaticShader() {
		super(VERTEX_FILE, FRAG_FILE);
	}

	@Override
	protected void bindAttributes() {
		super.bindAttribute(0, "position");
	}

	@Override
	protected void getAllUniformLocations() {
		location_transMatrix = super.getUniformLocation("transformationMatrix");
		location_projectionMatrix = super.getUniformLocation("projectionMatrix");
		location_viewMatrix = super.getUniformLocation("viewMatrix");
	}
	
	public void loadTransMatrix(Matrix4f matrix) {
		super.loadMatrix(location_transMatrix, matrix);
	}
	
	public void loadViewMatrix(Camera camera){
		Matrix4f viewMatrix = Maths.createViewMatrix(camera);
		super.loadMatrix(location_viewMatrix, viewMatrix);
	}
	
	public void loadProjectionMatrix(Matrix4f projection){
		super.loadMatrix(location_projectionMatrix, projection);
	}

}
