package com.voxelite.engine;

import org.joml.Vector3f;

public class RawModel {
	private int vaoID;
	private int vertexCount;
	
	private Vector3f position;
	private float rotX, rotY, rotZ;
	private float scale;
	
	public RawModel(int vaoID, int vertexCount, Vector3f position, float rotX, float rotY, float rotZ,
			float scale) {
		this.vaoID = vaoID;
		this.vertexCount = vertexCount;
		this.position = position;
		this.rotX = rotX;
		this.rotY = rotY;
		this.rotZ = rotZ;
		this.scale = scale;
	}

	public int getVaoID() {
		return vaoID;
	}

	public int getVertexCount() {
		return vertexCount;
	}
	
	public Vector3f getPosition() {
		return position;
	}

	public void setPosition(Vector3f position) {
		this.position = position;
	}

	public float getRotX() {
		return rotX;
	}

	public void setRotX(float rotX) {
		this.rotX = rotX;
	}

	public float getRotY() {
		return rotY;
	}

	public void setRotY(float rotY) {
		this.rotY = rotY;
	}

	public float getRotZ() {
		return rotZ;
	}

	public void setRotZ(float rotZ) {
		this.rotZ = rotZ;
	}

	public float getScale() {
		return scale;
	}

	public void setScale(float scale) {
		this.scale = scale;
	}

	
}
