package com.voxelite.core;

import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWVidMode;
import org.lwjgl.opengl.GL;

public class Window {
	private int width, height;
	private String windowTitle;
	private long window;
	
	public Window(int width, int height, String windowTitle) {
		this.width = width;
		this.height = height;
		this.windowTitle = windowTitle;
	}
	
	public void Create() {
		if (!GLFW.glfwInit()) {
			System.err.println("Error Code 1: Couldnt initialize GLFW");
			System.exit(-1);
		}
		GLFW.glfwDefaultWindowHints();
		GLFW.glfwWindowHint(GLFW.GLFW_CONTEXT_VERSION_MAJOR, 3);
		GLFW.glfwWindowHint(GLFW.GLFW_CONTEXT_VERSION_MINOR, 0);
		GLFW.glfwWindowHint(GLFW.GLFW_VISIBLE, GLFW.GLFW_FALSE);
		GLFW.glfwWindowHint(GLFW.GLFW_RESIZABLE, GLFW.GLFW_FALSE);
		window = GLFW.glfwCreateWindow(width, height, windowTitle, 0, 0);
		if (window == 0) {
			System.err.println("Error Code 2: Window couldnt be created");
			System.exit(-1);
		}
			
		GLFWVidMode videoMode = GLFW.glfwGetVideoMode(GLFW.glfwGetPrimaryMonitor());
		GLFW.glfwSetWindowPos(window,  (videoMode.width()-width)/2, (videoMode.height()-height)/2);
		
		GLFW.glfwShowWindow(window);
		GLFW.glfwMakeContextCurrent(window);
		
		GL.createCapabilities();
	}
	
	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}
	
	public boolean isClosed() {
		return GLFW.glfwWindowShouldClose(window);
	}
	
	public void Update() {
		GLFW.glfwPollEvents();
	}
	
	public void swapBuffers() {
		GLFW.glfwSwapBuffers(window);
	}
}
