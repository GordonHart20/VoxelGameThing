package com.voxelite.core;

import org.joml.Vector3f;

import com.voxelite.engine.Camera;
import com.voxelite.engine.ModelLoader;
import com.voxelite.engine.RawModel;
import com.voxelite.engine.Renderer;
import com.voxelite.lighting.StaticShader;

public class gameLoop {
	public static void main(String[] args) {
		Window window = new Window(800, 600, "Voxelite In_Dev1.0.0");
		window.Create();
		
		ModelLoader modelLoader = new ModelLoader();
		StaticShader shader = new StaticShader();
		Renderer renderer = new Renderer(window, shader);
		
		float[] vertices = {			
				-0.5f,0.5f,0,	
				-0.5f,-0.5f,0,	
				0.5f,-0.5f,0,	
				0.5f,0.5f,0,		
				
				-0.5f,0.5f,1,	
				-0.5f,-0.5f,1,	
				0.5f,-0.5f,1,	
				0.5f,0.5f,1,
				
				0.5f,0.5f,0,	
				0.5f,-0.5f,0,	
				0.5f,-0.5f,1,	
				0.5f,0.5f,1,
				
				-0.5f,0.5f,0,	
				-0.5f,-0.5f,0,	
				-0.5f,-0.5f,1,	
				-0.5f,0.5f,1,
				
				-0.5f,0.5f,1,
				-0.5f,0.5f,0,
				0.5f,0.5f,0,
				0.5f,0.5f,1,
				
				-0.5f,-0.5f,1,
				-0.5f,-0.5f,0,
				0.5f,-0.5f,0,
				0.5f,-0.5f,1
				
		};
		
		int[] indices = {
				0,1,3,	
				3,1,2,	
				4,5,7,
				7,5,6,
				8,9,11,
				11,9,10,
				12,13,15,
				15,13,14,	
				16,17,19,
				19,17,18,
				20,21,23,
				23,21,22

		};
				
		RawModel cube = modelLoader.loadToVAO(vertices, indices, new Vector3f(0, -5, 0), 0f, 0f, 0f, 1f);
		
		Camera camera = new Camera();

		
		while (!window.isClosed()) {
			System.out.println(camera.getPosition());
			//camera.Move();
			renderer.Prep();
			shader.start();
			shader.loadViewMatrix(camera);
			renderer.render(cube, shader);
			
			shader.stop();
			
			window.Update();
			window.swapBuffers();
		}
		
		shader.cleanUp();
		modelLoader.cleanUp();
	}
}
